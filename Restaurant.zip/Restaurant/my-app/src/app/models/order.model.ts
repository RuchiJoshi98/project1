export class MainOrderModel {
    ResName: string = "";
    NoOfPerson: number = 0;
    OrdMeal: string = "";
}

export class DishServingsModel{
    DishName: string = "";
    NoOfServings: number = 0;
    // DishServingsModel(DishName:string,NoOfServings: number){
    //     this.DishName = DishName;
    //     this.NoOfServings = NoOfServings;
    // }
}

export class DishModel{
    id  : number = 0;
    name: string = "";
    restaurant : string ="";
    availableMeals :Array<string> = [];
}

export class MealModel{
    name: string = "";
}