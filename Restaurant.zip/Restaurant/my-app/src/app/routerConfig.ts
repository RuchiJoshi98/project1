import { Routes } from "@angular/router";
import { OrderComponent } from "./order/order.component";
import { Step1Component } from "./order/steps/step1/step1.component";
import { Step2Component } from "./order/steps/step2/step2.component";
import { Step3Component } from "./order/steps/step3/step3.component";

const appRoutes: Routes = [
    {
        path: 'order',
        component: OrderComponent
    },

    {
        path: 'steps/step1',
        component: Step1Component 
    },

    {
        path: 'steps/step2',
        component: Step2Component
    },

    {
        path: 'steps/step3',
        component: Step3Component
    },
];

export default appRoutes;