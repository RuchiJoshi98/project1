import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { OrderComponent } from './order/order.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { StepsModule } from 'primeng/steps';
import { MenuModule } from 'primeng/menu';
import { MenuItem } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Step1Component } from './order/steps/step1/step1.component';
import { Step2Component } from './order/steps/step2/step2.component';
import { Step3Component } from './order/steps/step3/step3.component';
import { ReviewComponent } from './order/steps/review/review.component';
import appRoutes from './routerConfig';
// import { MdInputModule } from '@angular/material';
// import { MdInputModule } from '@angular/material';
import {ListboxModule} from 'primeng/listbox';

@NgModule({
  declarations: [
    AppComponent,
    OrderComponent,
    Step1Component,
    Step2Component,
    Step3Component,
    ReviewComponent,
    // MdInputModule   
  ],

  imports: [  
    MenuModule,
    ToastModule,
    StepsModule,
    
    // RouterModule.forRoot(appRoutes), 
    FormsModule,
    ListboxModule,
    BrowserModule,    
    NgSelectModule,
    AppRoutingModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,

    RouterModule.forRoot([
      { path:'',
        component: AppComponent
      }
    ])
    
  ],

  providers: [],
  bootstrap: [AppComponent]
})

export class AppModule { }
