import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { OrderService } from 'src/app/services/order.service';
import { DishModel, DishServingsModel, MainOrderModel, MealModel } from 'src/app/models/order.model';

@Component({
  selector: 'app-step3',
  templateUrl: './step3.component.html',
  styleUrls: ['./step3.component.css']
})

export class Step3Component implements OnInit {

  Step3Form: FormGroup;
  orderDetails: any;

  msgs: Message[] = [];
  items: MenuItem[] = [];
  activeIndex: number = 1;
  submitted: boolean = false;

  DishServingsModel :DishServingsModel=new DishServingsModel();

  dishes = [
    { id: 1, name: "Chicken Burger" },
    { id: 2, name: "Ham Burger" },
    { id: 3, name: 'Cheese Burger' },
    { id: 4, name: 'Fries' },
    { id: 5, name: 'Egg Muffin' },
    { id: 6, name: 'Burrito' },
    { id: 7, name: 'Tacos' },
    { id: 8, name: 'Quesadilla' },
    { id: 9, name: 'Steak' },
    { id: 10, name: 'Yakitori' },
    { id: 11, name: 'Nankotsu' },
    { id: 12, name: 'Piman' },
    { id: 13, name: 'Vegan Bento' },
    { id: 14, name: 'Coleslaw Sandwich' },
    { id: 15, name: 'Grilled Sandwich' },
    { id: 16, name: 'Veg. Salad' },
    { id: 17, name: 'Fruit Salad' },
    { id: 18, name: 'Corn Soup' },
    { id: 19, name: 'Tomato Soup' },
    { id: 20, name: 'Minestrone Soup' },
    { id: 21, name: 'Pepperoni Pizza' },
    { id: 22, name: 'Pepperoni Pizza' },
    { id: 23, name: 'Hawaiian Pizza' },
    { id: 24, name: 'Seafood Pizza' },
    { id: 25, name: 'Deep Dish Pizza' },
    { id: 26, name: 'Chow Mein' },
    { id: 27, name: 'Mapo Tofu' },
    { id: 28, name: 'Kung Pao' },
    { id: 29, name: 'Wontons' },
    { id: 30, name: 'Garlic Bread' },
    { id: 31, name: 'Ravioli' },
    { id: 32, name: 'Rigatoni Spaghetti' },
    { id: 33, name: 'Fettucine Pasta' },
  ];

  MealModel: MealModel = new MealModel();
  DishModel: DishModel = new DishModel();
  DishServingsData: Array<DishServingsModel> = [];
  MainOrderData: MainOrderModel = new MainOrderModel();
  

  constructor(
    private router: Router,
    private fb: FormBuilder,
    public orderService: OrderService,
  ) {

    this.Step3Form = this.fb.group({
      DishName: ['', Validators.required],
      NoOfServings: [1, Validators.required],
    });
  }

  ngOnInit(): void {

    if ( this.orderService.MainOrderData.OrdMeal == null || this.orderService.MainOrderData.OrdMeal ==''){
      this.orderService.activeIndex = 0;
      this.router.navigateByUrl('steps/step1');
    }

    this.Step3Form.patchValue({
      DishName: this.orderService.DishServingsModel.DishName,
      NoOfServings: this.orderService.DishServingsModel.NoOfServings,
    })

    console.log('Step3Form');
    console.log(this.Step3Form);

    console.log('DishServingsData');
    console.log(this.orderService.DishServingsData);

    console.log('Step3Form');
    console.log(this.Step3Form);

    this.dishes = [];

    this.orderService.AllDishesModelList.forEach((row) => {
      debugger
      if (row.restaurant == this.orderService.MainOrderData.ResName) {
        if (row.availableMeals.filter(row1 => row1 == this.orderService.MainOrderData.OrdMeal).length > 0) {
          this.dishes.push({ id: row.id, name: row.name });
        }
      }
    });
  }

  get f() { return this.Step3Form.controls; }

  onClickPrevious() {
    this.orderService.activeIndex = 1;
    this.router.navigateByUrl('steps/step2');
  }

  onAddClick() {
    console.log('on add click');

    if (this.Step3Form.get('NoOfServings')?.value == null || this.Step3Form.get('NoOfServings')?.value == 0 || this.Step3Form.get('DishName')?.value == null || this.Step3Form.get('DishName')?.value == "" ){
      return
    }

    this.DishServingsModel = new DishServingsModel();
    this.DishServingsModel.DishName = this.Step3Form.get('DishName')?.value;
    this.DishServingsModel.NoOfServings = this.Step3Form.get('NoOfServings')?.value;
    this.orderService.DishServingsData.push(this.DishServingsModel);

    console.log('DishServingsData');
    console.log(this.orderService.DishServingsData);

    // if (this.orderService.MainOrderModel.NoOfPerson == this.Step3Form.get('NoOfServings')?.value || this.orderService.MainOrderModel.NoOfPerson <= this.Step3Form.get('NoOfServings')?.value) {
    //   this.submitted = true;
    // } else {
    //   console.log('No of servings must be equal or greater than No of peoples');
    //   return;
    // }

  }

  onClickNext() {

    if (this.Step3Form.invalid){
      this.submitted = true;

      return;
    }

    var totalNoOfPerson: Number = 0
    var totalDisheServed: number = 0

    totalNoOfPerson = this.orderService.MainOrderData.NoOfPerson;
    if (totalNoOfPerson == null) {
      totalNoOfPerson = 0;
    }

    totalDisheServed = 0;

    for (var i: number = 0; i < this.orderService.DishServingsData.length; i++) {
      totalDisheServed = totalDisheServed + this.orderService.DishServingsData[i].NoOfServings;
    }

    if (totalNoOfPerson > totalDisheServed) {
      console.log("Total dish servings are less than total no of person");
      return;
    }

    this.orderService.activeIndex = 3;
    this.router.navigateByUrl('steps/review');
    // this.onAddClick();
  }

}
