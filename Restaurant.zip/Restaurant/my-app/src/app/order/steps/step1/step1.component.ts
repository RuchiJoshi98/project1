import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { MealModel } from 'src/app/models/order.model';
import { OrderService } from 'src/app/services/order.service';

@Component({
  selector: 'app-step1',
  templateUrl: './step1.component.html',
  styleUrls: ['./step1.component.css']
})

export class Step1Component implements OnInit {

  Step1Form: FormGroup;
  orderDetails: any;
  submitted: boolean = false;  

  meal:any = [];
  msgs: Message[] = [];
  items: MenuItem[] = [];
  activeIndex: number = 1;

  MealModel: MealModel = new MealModel();

  constructor(
    private router: Router,
    private fb: FormBuilder,
    public orderService: OrderService,
  ) { 
      this.Step1Form = this.fb.group({
        OrdMeal: ['', Validators.required],
        NoOfPerson: [1, Validators.required],
      });
  }

  ngOnInit(): void {

    if (this.orderService.MainOrderData.NoOfPerson == null ||this.orderService.MainOrderData.NoOfPerson ==0){
      this.orderService.MainOrderData.NoOfPerson = 1;
    }

    this.meal=[
      { id:"breakfast" , name: 'Breakfast' },
      { id:"lunch" , name: 'Lunch' },
      { id:"dinner" , name: 'Dinner' }
    ];
  

  debugger
    this.Step1Form.patchValue({
      OrdMeal: this.orderService.MainOrderData.OrdMeal,
      NoOfPerson: this.orderService.MainOrderData.NoOfPerson
    })

    console.log('Step1Form');
    console.log(this.Step1Form);
  }

  get f() { return this.Step1Form.controls; }

  onClickNext(){
    debugger;

    if (this.Step1Form.invalid){
      this.submitted = true;

      return;
    }

    this.orderService.MainOrderData.OrdMeal = this.Step1Form.get('OrdMeal')?.value;
    this.orderService.MainOrderData.NoOfPerson = this.Step1Form.get('NoOfPerson')?.value;

    console.log("MainOrderData");
    console.log(this.orderService.MainOrderData);

    this.orderService.activeIndex = 1;
    this.router.navigateByUrl('steps/step2');
  }

}
