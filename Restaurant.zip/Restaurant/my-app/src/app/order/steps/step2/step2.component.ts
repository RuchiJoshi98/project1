import { analyzeAndValidateNgModules } from '@angular/compiler';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { DishModel, DishServingsModel, MainOrderModel, MealModel } from 'src/app/models/order.model';
import { OrderService } from 'src/app/services/order.service';

@Component({
  selector: 'app-step2',
  templateUrl: './step2.component.html',
  styleUrls: ['./step2.component.css']
})

export class Step2Component implements OnInit {

  Step2Form: FormGroup;
  orderDetails: any;
  submitted: boolean = false;

  items: MenuItem[]=[];
  msgs: Message[] = [];
  activeIndex: number = 1;

  resnm=[
    { name: 'Mc Donalds' },
    { name: 'Taco Bell' },
    { name: 'BBQ Hut' },
    { name: 'Vege Deli' },
    { name: 'Pizzeria' },
    { name: 'Panda Express' },
    { name: 'Olive Garden' }
  ];

  MealModel: MealModel = new MealModel();
  DishModel: DishModel = new DishModel();
  
  DishServingsData: Array<DishServingsModel> = [];
  MainOrderData: MainOrderModel = new MainOrderModel();

  constructor(
    private router: Router,
    private fb: FormBuilder,
    public orderService: OrderService,

  ) {
      this.Step2Form = this.fb.group({
        ResName: ['', Validators.required],
      });
   }

  ngOnInit(): void {

    if ( this.orderService.MainOrderData.OrdMeal == null || this.orderService.MainOrderData.OrdMeal ==''){
      this.orderService.activeIndex = 0;
      this.router.navigateByUrl('steps/step1');
    }

    this.Step2Form.patchValue({
      ResName: this.orderService.MainOrderData.ResName
    });

    console.log('Step2Form');
    console.log(this.Step2Form);

    this.resnm = [];
    this.orderService.AllDishesModelList.forEach((row)=>{
      debugger
      if (row.availableMeals.filter(row1=> row1 == this.orderService.MainOrderData.OrdMeal).length > 0)
      {
        if (this.resnm.filter(row2 => row2.name == row.restaurant).length == 0){
          this.resnm.push({name:row.restaurant.toString()});
        }        
      }
    });
  }

  get f() { return this.Step2Form.controls; }

  onClickPrevious(){
    this.orderService.activeIndex = 0;
    this.router.navigateByUrl('steps/step1');
  }

  onClickNext(){
    
    if (this.Step2Form.invalid){
      this.submitted = true;

      return;
    } 

    this.orderService.MainOrderData.ResName = this.Step2Form.get('ResName')?.value;

    console.log("MainOrderData resName");
    console.log(this.orderService.MainOrderData)

    this.orderService.activeIndex = 2;
    this.router.navigateByUrl('steps/step3');
  }

}
