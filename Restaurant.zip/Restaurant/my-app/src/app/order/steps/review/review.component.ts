import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { DishServingsModel, MainOrderModel } from 'src/app/models/order.model';
import { OrderService } from 'src/app/services/order.service';

@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css']
})

export class ReviewComponent implements OnInit {

  ReviewForm: FormGroup;
  orderDetails: any;
  submitted: boolean = false;

  items: MenuItem[]=[];
  msgs: Message[] = [];
  activeIndex: number = 1;

  DishServingsData: Array<DishServingsModel> = [];
  MainOrderData: MainOrderModel = new MainOrderModel();
  DishServingsModel : DishServingsModel = new DishServingsModel();

  constructor(
    private router: Router,
    private fb: FormBuilder,
    public orderService:OrderService,
  ) {
      this.ReviewForm = this.fb.group({
        OrdMeal: ['', Validators.required],
        NoOfPerson: ['', Validators.required],
        ResName: ['', Validators.required],
        DishName: ['', Validators.required],
      });
   }

  ngOnInit(): void {

    // if ( this.orderService.MainOrderData.OrdMeal == null || this.orderService.MainOrderData.OrdMeal ==''){
    //   this.orderService.activeIndex = 0;
    //   this.router.navigateByUrl('steps/step1');
    // }

    this.ReviewForm.patchValue({
      OrdMeal: this.orderService.MainOrderData.OrdMeal,            
      NoOfPerson: this.orderService.MainOrderData.NoOfPerson,
      ResName: this.orderService.MainOrderData.ResName,
      DishName: this.orderService.DishServingsModel.DishName,
      NoOfServings: this.orderService.DishServingsModel.NoOfServings,
    })

    console.log('ReviewForm');
    console.log(this.ReviewForm);

    // this.orderService.DishServingsData.push(this.orderService.DishServingsModel);

    console.log('DishServingsData')
    console.log(this.orderService.DishServingsData);
  }

  onClickPrevious(){
    this.orderService.activeIndex = 2;
    this.router.navigateByUrl('steps/step3')
  }

  onClickSubmit(){

    console.log('Your order is submitted');

    console.log('Meal');
    console.log(this.orderService.MainOrderModel.OrdMeal);
    
    console.log('No of Person');
    console.log(this.orderService.MainOrderModel.NoOfPerson);

    console.log('Restaurant Name');
    console.log(this.orderService.MainOrderModel.ResName);
    
    console.log('Dish Name');
    console.log(this.orderService.DishServingsModel.DishName);

    console.log('No of Servings');
    console.log(this.orderService.DishServingsModel.NoOfServings);
    
  }

}

