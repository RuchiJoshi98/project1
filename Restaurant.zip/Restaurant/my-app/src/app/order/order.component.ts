import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms'
import { ActivatedRoute, Router } from '@angular/router';
import { NgSelectConfig } from '@ng-select/ng-select';
import { NgSelectModule } from '@ng-select/ng-select';
import { MenuItem } from 'primeng/api/menuitem';
import { MessageService } from 'primeng/api';
import { DishServingsModel, MainOrderModel } from 'src/app/models/order.model'
// import { StepsModule } from 'primeng/steps';
// import { MenuItem } from 'primeng/api';


@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',  
  styleUrls: ['./order.component.css'],
})

export class OrderComponent implements OnInit {
  
  constructor() { }

  ngOnInit(): void {

  }

}
