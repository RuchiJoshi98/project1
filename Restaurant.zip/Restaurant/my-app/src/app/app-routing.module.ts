import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Step1Component } from './order/steps/step1/step1.component';
import { Step2Component } from './order/steps/step2/step2.component';
import { Step3Component } from './order/steps/step3/step3.component';
import { ReviewComponent } from './order/steps/review/review.component';
import { OrderComponent } from './order/order.component';

const routes: Routes = [

  { path: '', 
    component: Step1Component 
  },


  { path: 'steps/step1', 
    component: Step1Component 
  },


  { path: 'steps/step2', 
    component: Step2Component 
  },

  { path: 'steps/step3', 
    component: Step3Component
  },

  { path: 'steps/review', 
    component: ReviewComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule {  
}
