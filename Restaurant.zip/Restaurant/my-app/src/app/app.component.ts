import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItem, MessageService } from 'primeng/api';
import { DishModel, MealModel  } from './models/order.model';
import { OrderService } from './services/order.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  // providers:[]
})

export class AppComponent   implements OnInit {
  title = 'my-app';

  
  items: MenuItem[] = [];
  
  constructor(
    private router: Router,
    public orderService:OrderService,
    // public messageService: MessageService,
  ) {

   }

  ngOnInit(): void {
    this.items = [{
      label: 'Step1',
      routerLink: 'steps/step1'
    },
    {
        label: 'Step2',
        routerLink: 'steps/step2'
    },
    {
        label: 'Step3',
        routerLink: 'steps/step3'
    },
    {
        label: 'Review',
        routerLink: 'steps/review'
    }
    ];

    this.orderService.AllDishesModelList = [];
    this.orderService.DishServingsData = [];
    this.orderService.AllDishesModelList = <Array<DishModel>> this.orderService.dishes;
    
    // this.orderService.dishes.array.forEach((element:DishModel) => {
    //   // DishModel.id = <number>element.id;
    //   this.DishModel.id = element.id;
    //   this.DishModel.name = element.name;
    //   this.DishModel.restaurant = element.restaurant;
    //   this.DishModel.availableMeals = element.availableMeals;
    //   this.orderService.AllDishesModelData.push(this.DishModel);
    // });
  }

  onClickNext(){
    this.router.navigateByUrl("order");
  }
}
